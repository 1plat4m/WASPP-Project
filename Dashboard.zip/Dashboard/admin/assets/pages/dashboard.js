
/*
 Template Name: Agroxa - Responsive Bootstrap 4 Admin Dashboard
 Author: Themesbrand
 File: Dashboard init js
 */

!function($) {
    "use strict";

    var Dashboard = function() {};
    
    //creates area chart
    Dashboard.prototype.createAreaChart = function (element, pointSize, lineWidth, data, xkey, ykeys, labels, lineColors) {
        Morris.Area({
            element: element,
            pointSize: 0,
            lineWidth: 0,
            data: data,
            xkey: xkey,
            ykeys: ykeys,
            labels: labels,
            resize: true,
            gridLineColor: '#eee',
            hideHover: 'auto',
            lineColors: lineColors,
            fillOpacity: .7,
            behaveLikeLine: true
        });
    },

    //creates Donut chart
    Dashboard.prototype.createDonutChart = function (element, data, colors) {
        Morris.Donut({
            element: element,
            data: data,
            resize: true,
            colors: colors
        });
    },

     //pie
        $('.peity-pie').each(function () {
            $(this).peity("pie", $(this).data());
        });

        //donut
        $('.peity-donut').each(function () {
            $(this).peity("donut", $(this).data());
        });

  
    
    Dashboard.prototype.init = function() {
        
        //creating area chart
        //creating area chart
            var $areaData = [
                {y: '2017', a: 2, b: 6, c:5},
                {y: '2018', a: 4, b: 3, c:6},
                {y: '2019', a: 1, b: 5, c:2},
                {y: '2020', a: 2, b: 6, c:1}
            ];
            this.createAreaChart('morris-area-example', 0, 0, $areaData, 'y', ['a', 'b', 'c'], ['Bugs', 'Defects', 'Upgrades'], ['#000000', '#f5b225', '#1b82ec']);

        // //creating donut chart
        // var $donutData = [
        //     {label: "Download Sales", value: 12},
        //     {label: "In-Store Sales", value: 30},
        //     {label: "Mail-Order Sales", value: 20}
        // ];
        // this.createDonutChart('morris-donut-example', $donutData, ['#f0f1f4', '#1b82ec', '#f5b225']);

    },
    //init
    $.Dashboard = new Dashboard, $.Dashboard.Constructor = Dashboard
}(window.jQuery),

//initializing 
function($) {
    "use strict";
    $.Dashboard.init();
}(window.jQuery);